<footer style="background-color: #388087 !important;"
    class="footer d-flex flex-wrap justify-content-between align-items-center px-5 py-3 mt-auto bg-secondary text-light">
    <span class="smaller-font">&copy; 2022 INTERN Group<br /><span class="xsmall-font">QUANG MINH, NHAT PHUONG, LAP KIEN</span></span>
    <ul class="nav justify-content-end list-unstyled d-flex">
        <li class="ms-3"><a class="text-light" target="_blank" href="https://github.com/NhatPhuong02/PHP-Project">
            <i class="bi bi-github"></i></a></li>
        <li class="ms-3"><a class="text-light" target="_blank" href="https://github.com/NhatPhuong02/PHP-Project">
            <i class="bi bi-facebook"></i></a></li>
    </ul>
</footer>